// Round 1: Advanced IT Questions
const round1Questions = [
    {
        question: "In object-oriented programming, which principle allows an object to take on many forms?",
        options: ["a) Encapsulation", "b) Inheritance", "c) Polymorphism", "d) Abstraction"],
        correctAnswer: 2
    },
    {
        question: "What is the primary function of a DNS server?",
        options: ["a) To manage email services", "b) To translate domain names into IP addresses", "c) To secure network traffic with encryption", "d) To store user passwords"],
        correctAnswer: 1
    },
    {
        question: "Which of the following is a type of non-volatile memory?",
        options: ["a) DRAM", "b) SRAM", "c) Cache Memory", "d) ROM"],
        correctAnswer: 3
    },
    {
        question: "A database schema defines the...",
        options: ["a) Data types of the data", "b) Relationships between tables", "c) Constraints on the data", "d) All of the above"],
        correctAnswer: 3
    },
    {
        question: "What is the purpose of a foreign key in a relational database?",
        options: ["a) To uniquely identify a record in a table", "b) To enforce referential integrity between two tables", "c) To speed up data retrieval", "d) To create a new index"],
        correctAnswer: 1
    },
    {
        question: "Which protocol is used to securely transfer files over a network?",
        options: ["a) FTP", "b) HTTP", "c) SFTP", "d) SMTP"],
        correctAnswer: 2
    },
    {
        question: "What does ACID stand for in the context of database transactions?",
        options: ["a) Atomicity, Consistency, Isolation, Durability", "b) Accessibility, Concurrency, Integrity, Data", "c) Atomicity, Concurrency, Integrity, Durability", "d) Accessibility, Consistency, Isolation, Data"],
        correctAnswer: 0
    },
    {
        question: "Which of the following sorting algorithms has the worst-case time complexity of O(n²)?",
        options: ["a) Merge Sort", "b) Quick Sort", "c) Insertion Sort", "d) Heap Sort"],
        correctAnswer: 2
    },
    {
        question: "Which of the following is a key characteristic of a public key infrastructure (PKI)?",
        options: ["a) It uses a single shared key for encryption and decryption.", "b) It relies on a Certificate Authority (CA) to verify digital identities.", "c) It is a protocol for real-time communication.", "d) It is primarily used for physical access control."],
        correctAnswer: 1
    },
    {
        question: "In networking, a 'subnet mask' is used for what purpose?",
        options: ["a) To hide the IP address of a device", "b) To determine which part of an IP address is the network address and which is the host address", "c) To filter incoming network traffic", "d) To assign IP addresses automatically via DHCP"],
        correctAnswer: 1
    },
    {
        question: "What is the main purpose of a firewall in a network?",
        options: ["a) To speed up network traffic", "b) To prevent unauthorized access to a network", "c) To manage email servers", "d) To store backups of data"],
        correctAnswer: 1
    },
    {
        question: "What does the term 'API' stand for?",
        options: ["a) Application Process Interface", "b) Automated Programming Instruction", "c) Application Programming Interface", "d) Advanced Protocol Integration"],
        correctAnswer: 2
    },
    {
        question: "Which data structure operates on the principle of 'Last-In, First-Out' (LIFO)?",
        options: ["a) Queue", "b) Stack", "c) Linked List", "d) Tree"],
        correctAnswer: 1
    },
    {
        question: "What is the purpose of a 'commit' command in a database transaction?",
        options: ["a) To discard all changes made during the transaction", "b) To save all changes permanently to the database", "c) To lock the database for exclusive access", "d) To create a new table"],
        correctAnswer: 1
    },
    {
        question: "In computer security, what is 'phishing'?",
        options: ["a) A type of malicious software that encrypts data", "b) A technique used to trick users into revealing personal information", "c) An attack that floods a server with traffic", "d) A method of securing a wireless network"],
        correctAnswer: 1
    },
    {
        question: "What is the primary function of a router in a computer network?",
        options: ["a) To manage and secure network traffic", "b) To translate domain names into IP addresses", "c) To connect different networks and forward data packets", "d) To boost the wireless signal in a network"],
        correctAnswer: 2
    }
];

// Round 2: Science and Math Questions
const round2Questions = [
    {
        question: "What is the powerhouse of the cell?",
        options: ["a) Nucleus", "b) Cytoplasm", "c) Mitochondria", "d) Ribosome"],
        correctAnswer: 2
    },
    {
        question: "What is the chemical formula for sulfuric acid?",
        options: ["a) $HCL$", "b) $HNO_3$", "c) $H_2SO_4$", "d) $NaOH$"],
        correctAnswer: 2
    },
    {
        question: "Which law states that energy cannot be created or destroyed, only transformed?",
        options: ["a) Law of Universal Gravitation", "b) Newton's First Law of Motion", "c) Law of Conservation of Energy", "d) Archimedes' Principle"],
        correctAnswer: 2
    },
    {
        question: "If a right-angled triangle has sides of length 3 and 4, what is the length of the hypotenuse?",
        options: ["a) 5", "b) 6", "c) 7", "d) 8"],
        correctAnswer: 0
    },
    {
        question: "What does the term 'photosynthesis' literally mean?",
        options: ["a) Light-creation", "b) Light-synthesis", "c) Light-destruction", "d) Life-creation"],
        correctAnswer: 1
    },
    {
        question: "What is the name of the process where a liquid turns into a gas without boiling?",
        options: ["a) Condensation", "b) Sublimation", "c) Evaporation", "d) Precipitation"],
        correctAnswer: 2
    },
    {
        question: "What is the formula for calculating force?",
        options: ["a) Force = Mass / Acceleration", "b) Force = Mass x Acceleration", "c) Force = Mass + Acceleration", "d) Force = Acceleration - Mass"],
        correctAnswer: 1
    }
];


// Get DOM elements
const quizTitle = document.querySelector('.quiz-title');
const questionText = document.getElementById('question-text');
const optionsContainer = document.getElementById('options-container');
const optionButtons = document.querySelectorAll('.option-btn');
const feedbackText = document.getElementById('feedback-text');
const nextBtn = document.getElementById('next-btn');
const quizBox = document.getElementById('quiz-box');
const resultsBox = document.getElementById('results-box');
const finalResultsText = document.getElementById('final-results-text');
const restartBtn = document.getElementById('restart-btn');
const timerDisplay = document.getElementById('timer-display');
const questionTurnDisplay = document.getElementById('question-turn-display');
const scoreDisplays = [
    document.querySelector('#score-box-1 span'),
    document.querySelector('#score-box-2 span'),
    document.querySelector('#score-box-3 span'),
    document.querySelector('#score-box-4 span')
];

// Get audio elements
const correctAudio = document.getElementById('correct-audio');
const wrongAudio = document.getElementById('wrong-audio');

// Game state variables
let currentQuestionIndex = 0;
let teamScores = [0, 0, 0, 0];
let currentTeamIndex = 0;
let answered = false;
let timerId;
const timerDuration = 10;
let currentRound = 1;

// Helper function to get questions for the current round
function getCurrentQuestions() {
    return currentRound === 1 ? round1Questions : round2Questions;
}

// Function to start the timer
function startTimer() {
    let timeLeft = timerDuration;
    timerDisplay.textContent = timeLeft;
    timerDisplay.classList.remove('danger');
    
    timerId = setInterval(() => {
        timeLeft--;
        timerDisplay.textContent = timeLeft;

        if (timeLeft <= 5) {
            timerDisplay.classList.add('danger');
        }

        if (timeLeft <= 0) {
            clearInterval(timerId);
            handleTimeout();
        }
    }, 1000);
}

// Function to handle the timeout event
function handleTimeout() {
    answered = true;
    feedbackText.textContent = `Team ${currentTeamIndex + 1}: Time's up! ⏰`;
    feedbackText.style.color = '#dc3545';
    wrongAudio.currentTime = 0;
    wrongAudio.play();
    nextBtn.disabled = false;
    optionButtons.forEach(btn => btn.disabled = true);
    
    const currentQuestion = getCurrentQuestions()[currentQuestionIndex];
    optionButtons[currentQuestion.correctAnswer].classList.add('correct');
}

// Function to load a question
function loadQuestion() {
    answered = false;
    nextBtn.disabled = true;
    feedbackText.textContent = '';
    
    clearInterval(timerId);
    optionButtons.forEach(btn => {
        btn.classList.remove('correct', 'wrong');
        btn.disabled = false;
    });

    const questions = getCurrentQuestions();
    if (currentQuestionIndex < questions.length) {
        if (currentRound === 1) {
             quizTitle.textContent = 'Advanced IT Quiz';
        } else {
             quizTitle.textContent = 'Science & Math Quiz';
        }
        questionTurnDisplay.textContent = `Question ${currentQuestionIndex + 1} for Team ${currentTeamIndex + 1}`;
        updateScoreDisplays();
        startTimer();
        const currentQuestion = questions[currentQuestionIndex];
        questionText.innerHTML = currentQuestion.question;
        optionButtons.forEach((btn, index) => {
            btn.innerHTML = currentQuestion.options[index];
            btn.setAttribute('data-index', index);
        });
    } else {
        showResults();
    }
}

// Function to update score displays
function updateScoreDisplays() {
    scoreDisplays.forEach((display, index) => {
        display.textContent = teamScores[index];
    });
}

// Function to check the selected answer
function checkAnswer(selectedIndex) {
    if (answered) return;
    answered = true;
    
    clearInterval(timerId);
    timerDisplay.classList.remove('danger');
    
    const questions = getCurrentQuestions();
    const currentQuestion = questions[currentQuestionIndex];
    const correctIndex = currentQuestion.correctAnswer;
    
    optionButtons.forEach(btn => btn.disabled = true);
    
    if (selectedIndex === correctIndex) {
        teamScores[currentTeamIndex]++;
        feedbackText.textContent = `Team ${currentTeamIndex + 1}: Correct! 🎉`;
        feedbackText.style.color = '#28a745';
        optionButtons[selectedIndex].classList.add('correct');
        correctAudio.currentTime = 0;
        correctAudio.play();
    } else {
        feedbackText.textContent = `Team ${currentTeamIndex + 1}: Incorrect. 😟`;
        feedbackText.style.color = '#dc3545';
        optionButtons[selectedIndex].classList.add('wrong');
        optionButtons[correctIndex].classList.add('correct');
        wrongAudio.currentTime = 0;
        wrongAudio.play();
    }
    
    nextBtn.disabled = false;
    updateScoreDisplays();
}

// Function to move to the next question
function nextQuestion() {
    currentQuestionIndex++;
    currentTeamIndex = (currentTeamIndex + 1) % 4;
    loadQuestion();
}

// Function to show the results (either end of round or end of game)
function showResults() {
    if (currentRound === 1) {
        currentRound = 2;
        currentQuestionIndex = 0;
        quizBox.style.display = 'block';
        resultsBox.style.display = 'none';
        questionText.textContent = 'Round 1 is over! Time for Round 2!';
        feedbackText.textContent = 'Click Next to begin the next round.';
        nextBtn.disabled = false;
        questionTurnDisplay.textContent = 'Current Standings:';
    } else {
        quizBox.style.display = 'none';
        resultsBox.style.display = 'block';

        const maxScore = Math.max(...teamScores);
        const winningTeams = teamScores.map((score, index) => ({ score, index }))
                                      .filter(team => team.score === maxScore);

        if (winningTeams.length === 1) {
            const winningTeamNumber = winningTeams[0].index + 1;
            finalResultsText.textContent = `Team ${winningTeamNumber} wins with a score of ${maxScore}! 🏆`;
        } else if (winningTeams.length > 1) {
            const winningTeamNumbers = winningTeams.map(team => `Team ${team.index + 1}`).join(', ');
            finalResultsText.textContent = `It's a tie! ${winningTeamNumbers} all scored ${maxScore}! 🤝`;
        } else {
            finalResultsText.textContent = `The game is over! All scores are 0.`;
        }
    }
}

// Function to restart the game
function restartGame() {
    currentQuestionIndex = 0;
    teamScores = [0, 0, 0, 0];
    currentTeamIndex = 0;
    currentRound = 1;
    quizBox.style.display = 'block';
    resultsBox.style.display = 'none';
    loadQuestion();
}

// Event listeners
optionsContainer.addEventListener('click', (event) => {
    if (event.target.classList.contains('option-btn')) {
        const selectedIndex = parseInt(event.target.getAttribute('data-index'));
        checkAnswer(selectedIndex);
    }
});

nextBtn.addEventListener('click', nextQuestion);
restartBtn.addEventListener('click', restartGame);

// Initial load
loadQuestion();