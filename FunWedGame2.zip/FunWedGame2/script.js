// Game Data (Kept the funny/hard sets)
const GAME_SETS = [
    {"answer": "Coffee", "clues": ["I'm the only reason your 7 AM meeting is not a felony.", "I turn 'Maybe later' into 'Let's do this now.'", "The magical bean water that tastes like the morning after a terrible decision."]},
    {"answer": "Sofa", "clues": ["My primary function is to trap lost TV remotes and ambition.", "Where diets go to die and naps spontaneously generate.", "My long-term goal is to achieve the shape of whoever sits on me the most."]},
    {"answer": "Toaster", "clues": ["I'm a kitchen appliance that burns bread with style.", "I'm the only thing in the house that requires you to actively push food away.", "I occasionally launch food into the air with the excitement of a small cannon."]},
    {"answer": "Pineapple", "clues": ["I'm a tropical fruit that looks like I'm having a bad hair day.", "I was once a symbol of wealth; now I start arguments on pizza.", "The only fruit that wears a crown but lives in a spiky armor."]},
    {"answer": "Internet", "clues": ["I'm the reason humanity created fire, language, and eventually, cat videos.", "A place where you can learn quantum physics and argue with a stranger about cats.", "My absence turns a productive adult into a bewildered, rocking caveman."]},
    {"answer": "Homework", "clues": ["I'm the only thing capable of multiplying faster than rabbits or interest rates.", "I'm the reason your pen ran out of ink at 11:59 PM.", "My main purpose is to convince parents they were never good at math either."]},
    {"answer": "Traffic", "clues": ["I’m proof that thousands of individual choices can result in collective misery.", "I’m a global phenomenon where everyone is trying to save time by accelerating time loss.", "My best friend is a radio host who tells you exactly why you're late."]},
    {"answer": "Balloon", "clues": ["I’m full of hot air, but not a politician.", "My greatest fear is anything sharp, especially pointy birthday hats.", "I sound like a frightened rubber monster when I die."]},
    {"answer": "Toothbrush", "clues": ["I'm involved in a high-stakes, two-minute cleaning ritual twice a day.", "I live in the bathroom and share a small paste with everyone in the family.", "My existence proves that even tiny plastic tools can fight armies of bacteria."]},
    {"answer": "Carrot", "clues": ["I promise great eyesight, but you still need glasses.", "I'm often held out as a reward, but I taste better in cake.", "Bugs Bunny's favorite, but I’m actually a root vegetable, not a magician’s wand."]}
];

// --- Team and Scoring State ---
const NUM_TEAMS = 4;
let availableSets = [...GAME_SETS]; 
let currentSet = null;
let clueIndex = 0; 
let currentTeam = 1; // Start with Team 1
let scores = {
    1: 0, 
    2: 0, 
    3: 0, 
    4: 0
};
// Scoring: Clue 1 = 15 points, Clue 2 = 10 points, Clue 3 = 5 points
const SCORE_MAP = [15, 10, 5]; 

// --- DOM Element References ---
const cluesList = document.getElementById('clues-list');
const nextClueButton = document.getElementById('next-clue-button');
const revealAnswerButton = document.getElementById('reveal-answer-button');
const nextButton = document.getElementById('next-button');
const currentTurnDisplay = document.getElementById('current-turn');
const guessFeedback = document.getElementById('guess-feedback');
const markCorrectButton = document.getElementById('mark-correct-button'); 


// --- CORE GAME FUNCTIONS ---

/**
 * Updates the score display on the screen.
 */
function updateScoreboard() {
    for (let i = 1; i <= NUM_TEAMS; i++) {
        document.getElementById(`team${i}-score`).textContent = `Team ${i}: ${scores[i]}`;
    }
    // Highlight the current team's turn
    currentTurnDisplay.textContent = `🔍 Team ${currentTeam}'s Turn!`;
}

/**
 * Switches the turn to the next team (1 -> 2 -> 3 -> 4 -> 1).
 */
function nextTeam() {
    currentTeam = (currentTeam % NUM_TEAMS) + 1;
    updateScoreboard();
}

/**
 * Resets the display and state for a new word set.
 */
function renderNewSet() {
    // 1. Reset Clue Index and List
    clueIndex = 0;
    cluesList.innerHTML = '';
    guessFeedback.textContent = '';
    
    // 2. Button State
    nextClueButton.disabled = false;
    nextClueButton.textContent = `Get Clue ${clueIndex + 1}`;
    markCorrectButton.disabled = false;
    revealAnswerButton.disabled = false;
    revealAnswerButton.textContent = 'Reveal Answer & Next Team';
    
    // Disable the main button until the round is over
    nextButton.disabled = true; 
    
    // 3. Render the first clue automatically for the new set
    addNextClue();
}

/**
 * Loads the next game set, rotates the team, and starts the new round.
 */
function loadNextSet() {
    if (availableSets.length === 0) {
        // Simple game over/restart
        availableSets = [...GAME_SETS];
        nextButton.textContent = 'Next Set';
    }

    // 1. Pick a random set and remove it from the available pool
    const randomIndex = Math.floor(Math.random() * availableSets.length);
    currentSet = availableSets.splice(randomIndex, 1)[0]; 
    
    // 2. Rotate team if this is not the very first load
    if (nextButton.textContent !== 'Start Game') {
        nextTeam();
    } else {
        // Set up initial state on first click
        updateScoreboard();
    }
    nextButton.textContent = 'Next Set'; // Update button after initial click

    // 3. Render the new set
    renderNewSet();
}

/**
 * Appends the next available clue to the list.
 */
function addNextClue() {
    if (!currentSet || clueIndex >= currentSet.clues.length) return;

    // Show the clue
    const clue = currentSet.clues[clueIndex];
    const listItem = document.createElement('li');
    listItem.textContent = `Clue ${clueIndex + 1}: ${clue}`;
    cluesList.appendChild(listItem);
    
    clueIndex++; // Increment index for the next call

    // Check if that was the last clue
    if (clueIndex >= currentSet.clues.length) {
        nextClueButton.textContent = "No More Clues";
        nextClueButton.disabled = true;
    } else {
        nextClueButton.textContent = `Get Clue ${clueIndex + 1}`;
    }
}

/**
 * Handles marking the current team's answer as correct.
 */
function markCorrect() {
    if (!currentSet) return;
    
    // clueIndex is 1-based, so use clueIndex - 1 to get the correct score index (0, 1, or 2)
    const points = SCORE_MAP[clueIndex - 1] || 0; 
    scores[currentTeam] += points;
    
    guessFeedback.textContent = `🎉 CORRECT! +${points} points for Team ${currentTeam}! The word was ${currentSet.answer}.`;
    
    // Disable round controls and enable 'Next Set'
    markCorrectButton.disabled = true;
    revealAnswerButton.disabled = true;
    nextClueButton.disabled = true;
    nextButton.disabled = false; // <-- ENABLE NEXT BUTTON
    
    updateScoreboard();
}

/**
 * Reveals the hidden answer and skips the current team's turn.
 */
function revealAnswerAndSkip() {
    if (!currentSet) return; 

    // Announce the skip
    guessFeedback.textContent = `Skipped! The word was **${currentSet.answer.toUpperCase()}**. Passing to the next team.`;
    
    // Disable round controls and enable 'Next Set'
    markCorrectButton.disabled = true;
    revealAnswerButton.disabled = true;
    nextClueButton.disabled = true;
    nextButton.disabled = false; // <-- ENABLE NEXT BUTTON

    // Since 'loadNextSet' handles the team rotation, we don't call nextTeam() here.
    // It will rotate on the next click of the 'Next Set' button.
}


// --- Event Listeners ---
nextButton.addEventListener('click', loadNextSet);
nextClueButton.addEventListener('click', addNextClue);
markCorrectButton.addEventListener('click', markCorrect);
revealAnswerButton.addEventListener('click', revealAnswerAndSkip);


// --- Initial Game Setup ---
// The game waits for the user to click 'Start Game'
nextButton.disabled = false; // Ensure 'Start Game' is enabled initially
updateScoreboard();